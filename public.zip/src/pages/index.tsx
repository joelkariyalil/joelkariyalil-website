import Layout from '@/components/Layout';
import Image from 'next/image';
import BackgroundCanvas from '@/components/BackgroundCanvas';

export default function HomePage() {
  return (
    <Layout title="Home">
      <BackgroundCanvas />

      <section className="min-h-screen flex flex-col justify-center px-6 relative z-10 bg-transparent">
        <div className="flex flex-col md:flex-row items-center justify-between max-w-5xl mx-auto w-full space-y-10 md:space-y-0">
          {/* LEFT: Text Section */}
          <div className="text-left md:w-1/2">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">Joel Thomas Chacko</h1>
            <p className="text-gray-600 mt-4 text-lg leading-relaxed max-w-md">
              I'm a software developer who enjoys building minimal, elegant systems that help people think clearly.
              This site is where I occasionally share projects and thoughts.
            </p>
          </div>

          {/* RIGHT: Profile Image */}
          {/* RIGHT: Profile Image */}
          <div className="md:w-1/2 flex justify-center">
            <div className="w-72 h-72 rounded-full overflow-hidden shadow-md">
              <Image
                src="/profile.jpg"
                alt="Joel Thomas Chacko"
                width={288}
                height={288}
                className="object-cover w-full h-full"
                priority
              />
            </div>
          </div>

        </div>
      </section>
    </Layout>
  );
}
