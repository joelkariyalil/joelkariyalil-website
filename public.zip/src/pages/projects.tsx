import Layout from '@/components/Layout';

const ProjectsPage: React.FC = () => (
  <Layout title="Projects">
    <h1 className="text-2xl font-bold mb-4">Projects</h1>
    <p>Coming soon...</p>
  </Layout>
);

export default ProjectsPage;
